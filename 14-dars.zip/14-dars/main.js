function myFunction2() {
    var element = document.getElementById("drop");
    element.classList.toggle("open");
}